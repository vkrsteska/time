<?php
	$_ENV['DB_HOST']        = "localhost";
	$_ENV['DB_DATABASE']    = "checkintime";
	$_ENV['DB_USERNAME']    = "checkintime";
	$_ENV['DB_PASSWORD']    = "ZSzSQ1mWI88SBsv";
