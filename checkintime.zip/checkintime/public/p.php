<?php  phpinfo();
/**
 * Created by PhpStorm.
 * User: vasko.torkov
 * Date: 26.03.2015
 * Time: 16:57
 */