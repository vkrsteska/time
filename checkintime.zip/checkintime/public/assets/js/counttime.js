$(function(){
    ////var start_time = $('#start_time').val();
    console.log($('#start_time').val());
    //countdown.setLabels(
    //    '|:',
    //    '|:',
    //    ':');
    var today = new Date();
    
    if ($('#start_time').val() != 0)
        setInterval('updateClock()', 1000);
    //updateClock();
});

function updateClock ()
{
    var currentTime = new Date($('#start_time').val());
// console.log('Denes e: ' + currentTime);
    var timerId =
        countdown(
            currentTime,
            new Date(),
            countdown.HOURS|countdown.MINUTES|countdown.SECONDS);

    $('#clock').html(timerId.toString());

}