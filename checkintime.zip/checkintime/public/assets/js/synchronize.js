$(function(){
	var synchronize = $(".synchronize");
	var info = $(".sync_info");
	info.hide();

	synchronize.click(function(e){
		e.preventDefault();

		var url = $(this).attr('href');

		$(".nav_buttons").children().addClass("disabled");
		info.html("Synchronizing. Please wait...");
		$(this).find('i').addClass("fa-spin");
		$.ajax({
			url: url,
			type: 'get',
			dataType: 'html',
			success: function(response){
                info.html(response);
				info.show();
				$(".nav_buttons").children().removeClass("disabled");
				$(".synchronize i").removeClass("fa-spin");
			}
		});
	});
});