<?php namespace Library\Export;
 
use PDF;
use Times;
use Employees;

use Library\Helpers\Helper;
use Library\Cron\CronLog;

use Excel;

	class PDFExporter{
		public static function export($times,$path=false,$emp=null,$type="xls",$interface=0){

			$data['interface'] = $interface;
            if ($emp != -1)
            {
                $name = Employees::where('cardnum',$emp)->first();
                if($name)
                    $data['name'] = $name->empname;
                else
                    $data['name'] = $emp;
			}
            else
            {
            	$name = 'cите вработени';
                $data['name'] = 'СИТЕ ВРАБОТЕНИ';
                $emp = 'site-vraboteni';
            }

            $data['times'] = $times;

			if($path){
				// CronLog::write("Recodrs export from command line for emp: ".$emp, date("Y-m-d H:i:s"));
				//     		return $pdf->save("C:\\Reports\\".$emp."-".date('Ymd-His').".".$type);
			}
        	else
            {
        		CronLog::write("Records export for emp: ".$emp,date("Y-m-d H:i:s"));
        		Excel::create($emp."-".date('Ymd-His'), function($excel) use ($data){

				    $excel->sheet('New sheet', function($sheet) use ($data){
				    	if($data['interface']==1){
				    		// unset($data['interface']);
				       	 	$sheet->loadView('export.pdf2',$data);
				    	}
				       	else
				       		$sheet->loadView('export.pdf',$data);

				    });

				})->export("xls");
        	}
		}

		public static function exportTotal($times,$path=false,$emp=null,$type="xls",$interface=0){

			$data['interface'] = $interface;
            if ($emp != -1)
            {
                $name = Employees::where('cardnum',$emp)->first();
                if($name)
                    $data['name'] = $name->empname;
                else
                    $data['name'] = $emp;
			}
            else
            {
                $data['name'] = 'СИТЕ ВРАБОТЕНИ';
                $emp = 'site-vraboteni';
            }
            $data['times'] = $times;
			if($path){
				// CronLog::write("Recodrs export from command line for emp: ".$emp, date("Y-m-d H:i:s"));
				//     		return $pdf->save("C:\\Reports\\".$emp."-".date('Ymd-His').".".$type);
			}
        	else
            {
        		CronLog::write("Records export for emp: ".$emp,date("Y-m-d H:i:s"));
        		Excel::create($emp."-".date('Ymd-His'), function($excel) use ($data){

				    $excel->sheet('New sheet', function($sheet) use ($data){
				    	if($data['interface']==1){
				    		// unset($data['interface']);
				       	 	$sheet->loadView('export.pdf2',$data);
				    	}
				       	else
				       		$sheet->loadView('export.pdftotal',$data);

				    });

				})->export("xls");
        	}
		}

		public static function exportFromCommand($from,$to,$emp){

			if($from=="" || strlen($from)==0) $from = date('Y-m-d', mktime(0, 0, 0, date('m'), date('d'), date('Y')));
			else $from = date('Y-m-d', strtotime($from));
			if($to=="" || strlen($to)==0) $to = date('Y-m-d');
			else $to = date('Y-m-d', strtotime($to));

			if(!$emp || $emp==null || $emp==-1)
			{
				$times = Times::where('sdate','>=',$from)
							  ->where('sdate','<=',$to)
							  ->orderBy('sdate','desc')
							  ->get();
				$emp = "All employees";
			}
			elseif($emp)
			{
				$times = Times::where('sdate','>=',e($from))
							  ->where('sdate','<=',e($to))
							  ->where('event_card','=',e($emp))
							  ->orderBy('sdate','desc')
							  ->get();
			}
			return self::export(Helper::manageTimes($times->toArray()),true,$emp);
		}
	}