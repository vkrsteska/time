<?php namespace Library\Helpers;
class Helper{
	
	public static function sortBySubkey(&$array, $subkey, $sortType = SORT_ASC) 
	{
        $keys = array();
	    foreach ($array as $subarray) {
	        $keys[] = $subarray[$subkey];
	    }
	    array_multisort($keys, $sortType, $array);
	}

	public static function manageTimes($times, $interface = 0)
	{
		$return = array();
        $prev_day_end = '-';

		if(is_array($times) && count($times) > 0 )
		{
            $times = array_reverse($times);
            $day_start_arr = $day_end_arr = array();
			foreach($times as $key=>$value)
			{
				if(!array_key_exists($value['sdate'], $return))
					$return[$value['sdate']] = array();
					
				if(!array_key_exists($value['emp_name'], $return[$value['sdate']]))
					$return[$value['sdate']][$value['emp_name']] = array();
					
				//if(!array_key_exists($value['doorno'], $return[$value['sdate']][$value['emp_name']]))
				//	$return[$value['sdate']][$value['emp_name']][$value['doorno']] = array();

                //array_push($return[$value['sdate']][$value['emp_name']][$value['doorno']], $value);
                array_push($return[$value['sdate']][$value['emp_name']], $value);
                if ($value['doorno'] == 1)
                    $day_start_arr[$value['sdate']][$value['emp_name']][] = strtotime($value['stime']);
                if ($value['doorno'] == 2)
                    $day_end_arr[$value['sdate']][$value['emp_name']][] = strtotime($value['stime']);

			}

//            if (count($times) == 3 AND empty($day_end_arr))
//            {
//                $date_obj = \DateTime::createFromFormat('Y-m-d', $times[0]['sdate']);
//
//                $date_obj->add(new \DateInterval('P1D'));
//
//                $next_day = $date_obj->format('Y-m-d');
//
//            }
			foreach($return as $date=>$names)
			{
				foreach($names as $emp=>$values)
				{
					foreach($values as $button=>$val)
					{
						self::sortBySubkey($return[$date][$emp], 'stime');
					}
				}
			}

            foreach($return as $date=>$name)
            {
                foreach($name as $emp=>$values)
                {
                    if (!isset($return[$date][$emp]))
                    {
                        dd($emp);
                    }
                    else
                        self::sortBySubkey($return[$date][$emp], 'id');

                    $return[$date][$emp] = array_reverse($return[$date][$emp]);
    
                    if (!empty($day_end_arr[$date][$emp]))
                        $return[$date][$emp]['day_end'] = date('H:i:s', max($day_end_arr[$date][$emp]));
                    else
                    {
                        $date_obj_end = \DateTime::createFromFormat('Y-m-d', $date);
                        
                        $date_obj_end->add(new \DateInterval('P1D'));
                        
                        $next_day = $date_obj_end->format('Y-m-d');

//                        if ($date == '2015-07-31') dd('here1');
                        if ( empty($day_start_arr[$next_day][$emp]) 
                        AND !empty($day_end_arr[$next_day][$emp]))  //if no start time exists the next day, but end time does
                        {
//                            if ($date == '2015-07-31') dd('1');

                            $return[$date][$emp]['day_end'] =  date('H:i:s', min($day_end_arr[$next_day][$emp]) );
                            // unset($return[$next_day][$emp]);  //don't show next day since it only has end time that belongs to the current day
                        }    
                        elseif ( !empty($day_start_arr[$next_day][$emp]) 
                        AND !empty($day_end_arr[$next_day][$emp]))  //if start and end time exist the next day
                        {
//                            if ($date == '2015-07-31') dd('2');

                            if ( min($day_end_arr[$next_day][$emp]) < min($day_start_arr[$next_day][$emp]) ) //if the earliest end time is smaller than the earilest start time
                                $return[$date][$emp]['day_end'] =  date('H:i:s', min($day_end_arr[$next_day][$emp]) ); //it means it belongs to the previous day
                            else
                                $return[$date][$emp]['day_end'] = 'NO END TIME!';
                        }
                        else
                        {
//                            if ($date == '2015-07-31') dd('3');
                            $return[$date][$emp]['day_end'] = 'NO END TIME!';
                        }
                    }
                    
                    if (!empty($day_start_arr[$date][$emp]))
                        $return[$date][$emp]['day_start'] = date('H:i:s', min($day_start_arr[$date][$emp]));
                    else
                    {
//                         $date_obj_start = \DateTime::createFromFormat('Y-m-d', $date);
//
//                         $date_obj_start->sub(new \DateInterval('P1D'));
//
//                         $prev_day = $date_obj_start->format('Y-m-d');
//
//                         $prev_day_arr = \Times::where('sdate', '=', $prev_day)
//                         ->where('emp_name', '=', $emp)->get()->toArray();
//
//
//                         $prev_day_arr = self::manageTimes($prev_day_arr, $interface);
//                        dd('here');
//                        if ($prev_day_end != '-' AND $date == '2015-07-31') var_dump('here');
//                        if ($prev_day_end != '-' AND $date == '2015-08-01') var_dump($prev_day_end);
                         if ( $prev_day_end == $return[$date][$emp]['day_end'])  //if end time for the previous day is the same as today's end time
                         {
                             unset($return[$date][$emp]);  //don't show this day since it only has end time that belongs to the previous day
                             continue;
                         }
                         else
                            $return[$date][$emp]['day_start'] = 'NO START TIME!';
                    }
                    if ($interface == 1)
                            $return[$date][$emp]['break'] = self::getBreak($values);

                    $return[$date][$emp] = array_reverse($return[$date][$emp]);

                }

                if (!empty($return[$date])){
                    $prev_day_end = $return[$date][$emp]['day_end']; 
                    // print_r($prev_day_end);
                    // exit;
                }
                    
                else
                    unset($return[$date]);

            }


		}
		return $return;	

	}

    public static function manageTotalTimes($times, $interface = 0) {
        $return = array();
        $total_time = 0;
        $prev_day_end = '-';

        if(is_array($times) && count($times) > 0 )
        {
            $times = array_reverse($times);
            $day_start_arr = $day_end_arr = array();
            foreach($times as $key=>$value)
            {
                if(!array_key_exists($value['sdate'], $return))
                    $return[$value['sdate']] = array();
                    
                if(!array_key_exists($value['emp_name'], $return[$value['sdate']]))
                    $return[$value['sdate']][$value['emp_name']] = array();
                    
                //if(!array_key_exists($value['doorno'], $return[$value['sdate']][$value['emp_name']]))
                //  $return[$value['sdate']][$value['emp_name']][$value['doorno']] = array();

                //array_push($return[$value['sdate']][$value['emp_name']][$value['doorno']], $value);
                array_push($return[$value['sdate']][$value['emp_name']], $value);
                if ($value['doorno'] == 1)
                    $day_start_arr[$value['sdate']][$value['emp_name']][] = strtotime($value['stime']);
                if ($value['doorno'] == 2)
                    $day_end_arr[$value['sdate']][$value['emp_name']][] = strtotime($value['stime']);
            }
//            if (count($times) == 3 AND empty($day_end_arr))
//            {
//                $date_obj = \DateTime::createFromFormat('Y-m-d', $times[0]['sdate']);
//
//                $date_obj->add(new \DateInterval('P1D'));
//
//                $next_day = $date_obj->format('Y-m-d');
//
//            }
            foreach($return as $date=>$names)
            {
                foreach($names as $emp=>$values)
                {
                    foreach($values as $button=>$val)
                    {
                        self::sortBySubkey($return[$date][$emp], 'stime');
                    }
                }
            }

            foreach($return as $date=>$name)
            {
                foreach($name as $emp=>$values)
                {
                    if (!isset($return[$date][$emp]))
                    {
                        dd($emp);
                    }
                    else
                        self::sortBySubkey($return[$date][$emp], 'id');

                    $return[$date][$emp] = array_reverse($return[$date][$emp]);
    
                    if (!empty($day_end_arr[$date][$emp]))
                        $return[$date][$emp]['day_end'] = date('H:i:s', max($day_end_arr[$date][$emp]));
                    else
                    {
                        $date_obj_end = \DateTime::createFromFormat('Y-m-d', $date);
                        
                        $date_obj_end->add(new \DateInterval('P1D'));
                        
                        $next_day = $date_obj_end->format('Y-m-d');

//                        if ($date == '2015-07-31') dd('here1');
                        if ( empty($day_start_arr[$next_day][$emp]) 
                        AND !empty($day_end_arr[$next_day][$emp]))  //if no start time exists the next day, but end time does
                        {
//                            if ($date == '2015-07-31') dd('1');

                            $return[$date][$emp]['day_end'] =  date('H:i:s', min($day_end_arr[$next_day][$emp]) );
                            // unset($return[$next_day][$emp]);  //don't show next day since it only has end time that belongs to the current day
                        }    
                        elseif ( !empty($day_start_arr[$next_day][$emp]) 
                        AND !empty($day_end_arr[$next_day][$emp]))  //if start and end time exist the next day
                        {
//                            if ($date == '2015-07-31') dd('2');

                            if ( min($day_end_arr[$next_day][$emp]) < min($day_start_arr[$next_day][$emp]) ) //if the earliest end time is smaller than the earilest start time
                                $return[$date][$emp]['day_end'] =  date('H:i:s', min($day_end_arr[$next_day][$emp]) ); //it means it belongs to the previous day
                            else
                                $return[$date][$emp]['day_end'] = 'NO END TIME!';
                        }
                        else
                        {
//                            if ($date == '2015-07-31') dd('3');
                            $return[$date][$emp]['day_end'] = 'NO END TIME!';
                        }
                    }
                    
                    if (!empty($day_start_arr[$date][$emp]))
                        $return[$date][$emp]['day_start'] = date('H:i:s', min($day_start_arr[$date][$emp]));
                    else
                    {
//                         $date_obj_start = \DateTime::createFromFormat('Y-m-d', $date);
//
//                         $date_obj_start->sub(new \DateInterval('P1D'));
//
//                         $prev_day = $date_obj_start->format('Y-m-d');
//
//                         $prev_day_arr = \Times::where('sdate', '=', $prev_day)
//                         ->where('emp_name', '=', $emp)->get()->toArray();
//
//
//                         $prev_day_arr = self::manageTimes($prev_day_arr, $interface);
//                        dd('here');
//                        if ($prev_day_end != '-' AND $date == '2015-07-31') var_dump('here');
//                        if ($prev_day_end != '-' AND $date == '2015-08-01') var_dump($prev_day_end);
                         if ( $prev_day_end == $return[$date][$emp]['day_end'])  //if end time for the previous day is the same as today's end time
                         {
                             unset($return[$date][$emp]);  //don't show this day since it only has end time that belongs to the previous day
                             continue;
                         }
                         else
                            $return[$date][$emp]['day_start'] = 'NO START TIME!';
                    }
                    

                    $return[$date][$emp] = array_reverse($return[$date][$emp]);

                }

                if (empty($return[$date]))
                    unset($return[$date]);
                else
                    $prev_day_end = $return[$date][$emp]['day_end'];
            }


        }
        return $return; 
    }
	public static function getBreak($employee_times)
    {
        $return = array(
            'total' => '00:00:00',
            'from_to' => ''
        );

        if (isset($employee_times) && count($employee_times) > 0) {

            $start_break = $end_break = $break_duration = '';

            foreach ($employee_times as $key => $arr) {

                if ($arr["doorno"] != 3)
                    continue;

                $start_break = $arr['stime'];

                $min = rand(25, 35);
                $sec = rand(0, 59);
                $break_duration = date('H:i:s', strtotime('00:' . $min . ':' . $sec));

                $end_break = self::sum_the_time($start_break, $break_duration);
                break; //we only need the first break, if it exists
            }

            if ($start_break != '')
            {
                $return['total'] = $break_duration;
                $return['from_to'] = $start_break . ' - ' . $end_break;
            }
        }

        return $return;
    }

	public static function sum_the_time($time1, $time2) {
	  $times = array($time1, $time2);
	  $seconds = 0;
	  foreach ($times as $time)
	  {
	    list($hour,$minute,$second) = explode(':', $time);
	    $seconds += $hour*3600;
	    $seconds += $minute*60;
	    $seconds += $second;
	  }
	  $hours = floor($seconds/3600);
	  $seconds -= $hours*3600;
	  $minutes  = floor($seconds/60);
	  $seconds -= $minutes*60;

	  return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
	}

    public static function rectime($secs) {
        $hr = floor($secs / 3600);
        $min = floor(($secs - ($hr * 3600))/60);
        $sec = $secs - ($hr * 3600) - ($min * 60);

        if ($hr < 10) {$hr = "0" . $hr; }
        if ($min < 10) {$min = "0" . $min;}
        if ($sec < 10) {$sec = "0" . $sec;}
        if ($hr == "0") {$hr = "00";}
        return $hr . ':' . $min . ':' . $sec;
    }
}