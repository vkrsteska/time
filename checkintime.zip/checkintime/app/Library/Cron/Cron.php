<?php namespace Library\Cron;

use Employees;
use Times;
//use Helpers\CronLog;

class Cron{
	
//	private  $_conn = null;
    private  $dump_rsa = '/dbdump/rsa241.sql';
    private  $dump_emp = '/dbdump/emp.sql';

	public function __construct(){

//		$db_file = '../../../accdb/HDTA_a.MDB';
//
//		$db_user = '';
//		$db_pass = 'ACC2583';

		// make connection with database
		//$this->_conn = odbc_connect("Driver={Microsoft Access Driver (*.mdb)};Dbq=$db_file", $db_user, $db_pass);

//        $this->_conn = \DB::connection('odbc');

        exec('PATH=$PATH:/usr/bin; /usr/bin/mdb-export -I mysql '. base_path().'/accdb/HDTA_a.MDB rsa241 | /bin/sed -e \'s/)$/)\;/\' > '. base_path().$this->dump_rsa, $return);
        exec('PATH=$PATH:/usr/bin; /usr/bin/mdb-export -I mysql '. base_path().'/accdb/HDTA_a.MDB emp | /bin/sed -e \'s/)$/)\;/\' > '. base_path().$this->dump_emp, $return);

//		if (!$this->_conn){
//		  CronLog::write("Connection Failed: ".$this->_conn, date("Y-m-d H:i:s"));
//		  exit("Connection Failed: " .$this->_conn);
//		}
	}

	public function synchronizeAll()
	{
		$data['synced_employees'] 	= stripslashes($this->synchronizeEmp());
		$data['synced_times'] 		= stripslashes($this->synchronizeTimes());

		return implode('<br/>', $data);
	}

	public function synchronizeEmp()
	{

		$totalSync = 0;
        $dump = file(base_path().$this->dump_emp, FILE_IGNORE_NEW_LINES);
        natsort($dump);
        $totalPulled = count($dump);

       Employees::truncate();

		// GET THE EMPLOYEES

        foreach ($dump AS $line_num => $line)
        {
            if (\DB::unprepared($line))
                $totalSync++;
            else
                CronLog::write("Failed to insert row in emp table. query: {$line}", date('Y-m-d H:i:s'));
        }

		CronLog::write('Synchronized employees: '.$totalSync.'/'.$totalPulled, date('Y-m-d H:i:s'));
    	return 'Synchronized employees: <strong>'.$totalSync.' of '.$totalPulled.'</strong> records.<br/>';
	}

	public function synchronizeTimes()
	{
        $totalSync = 0;
        $dump = file(base_path().$this->dump_rsa, FILE_IGNORE_NEW_LINES);
        natsort($dump);
        $totalPulled = count($dump);


        $id = $this->getLastTimesID();

        $has_records = ($id != 0) ? true : false;
        $passed_last = false;

        // GET THE TIMES

        foreach ($dump AS $line_num => $line)
        {
            if ($has_records)
            {
                if (stripos($line, 'VALUES (' . $id) === FALSE AND !$passed_last)
                {
//                    unset($dump[$line_num]);
                    continue;
                }

                if (stripos($line, 'VALUES (' . $id) !== FALSE)
                {
                    $passed_last = true;
//                    unset($dump[$line_num]);
                    continue;
                }
            }
            if (\DB::unprepared($line))
                $totalSync++;
            else
                CronLog::write("Failed to insert row in rsa241 table. query: {$line}", date('Y-m-d H:i:s'));
        }
//        $dump = implode("\n", $dump);
//        file_put_contents(base_path().'/dbdump/rest.sql', $dump);

		CronLog::write('Synchronized times: '.$totalSync.'/'.$totalPulled, date('Y-m-d H:i:s'));
		return 'Synchronized times: <strong>'.$totalSync.' of '.$totalPulled.'</strong> records.<br/>';
	}

	private function getLastTimesId()
	{
        $id = TIMES::max('num');

		return $id!=null ? $id : 0;
	}

}
