#!/bin/bash
PATH=$PATH:/usr/bin:/bin;
/usr/bin/mdb-export -I /usr/bin/mysqldump /public/prog/public_projects/cosmic/checkintime/accdb/HDTA_a.MDB rsa241 | /bin/sed -e "s/)$/)\;/" > /public/prog/public_projects/cosmic/checkintime/test.sql