<?php namespace Library\Cron;

use File;

class CronLog{
	
	private static $_log_name = "cron.log";

	public static function write($text,$date){
		$path = storage_path()."\\logs\\".self::$_log_name;

		if(File::exists($path)){
			File::append($path,$text."\t\t".$date."\n");
		}
		else{
			File::put($path,$text."\t\t".$date."\n");
		}
	}


}