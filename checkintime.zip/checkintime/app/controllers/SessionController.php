<?php

class SessionController extends \BaseController {

	protected $session;

	public function __construct(User $session)
	{
		$this->session = $session;
	}

	public function index()
	{
		return View::make('user.login');
	}

	public function sessionStart()
	{
		$remember_me	=	Input::get('remember_me')=='on' ? true : false; 

		$user	=	Auth::attempt(array(
			'email'		=>	e(Input::get('email')),
			'password'	=>	e(Input::get('password'))
		), $remember_me);

		if($user)
		{
			if(!Auth::user()->isAdmin())
				return Redirect::intended('profile');
			else
				return Redirect::intended('/admin/dashboard');
		}
	
		$data['message']		=	'Failed to log you in. Check your credentials!';
		$data['message_type']	=	'danger';

		return Redirect::back()->with($data)->withInput();
	}

	public function getSessionRegister()
	{
		return View::make('user.register');
	}
    
    public function getResetPasswordForm()
    {
        $data = [];
        if (Input::get('email') != '')
        {            
            $data['message']		=	'Password reset link sent. Please check your email.';
            $data['message_type']	=	'success';
        }
        
        
        
        return View::make('user.reset_pass', $data);
    }

	public function postSessionRegister()
	{
		$input 	=	Input::all();

		if(!$this->session->isValid($input)){
			return Redirect::back()->withInput()->withErrors($this->session->errors);
		}
		


		$this->session->card_number 	= e(Input::get('card_number'));
		$this->session->first_name 		= e(Input::get('first_name'));
		$this->session->last_name 		= e(Input::get('last_name'));
		$this->session->email 			= e(Input::get('email'));
		$this->session->password 		= Hash::make(e(Input::get('password')));
		
		$emp = Employees::where('cardnum',e(Input::get('card_number')));

		if(!$emp){
			$data['message']			= "The card number you entered is not valid or doesn't exists!";
			$data['message_type']		= "danger";
			return Redirect::back()->withInput()->with($data);
		}

		if($this->session->save())
		{
			$data['message']			= "Account created successfuly. You can now sing in.";
			$data['message_type']		= "success";
		}	
		else
		{
			$data['message']			= "Failed to create account. Try again!";
			$data['message_type']		= "danger";
		}

		return Redirect::action('SessionController@index')->with($data);
	}

	public function getUser($cardnum)
	{
		if(Request::ajax())
		{
			$user = Employees::where('cardnum',e($cardnum))->first();

			if($user)
			{
				$name = explode(" ",$user->empname);
				$data = [
							"success" => '1', 
							"first_name" => $name[0], 
							"last_name" => $name[1],
						];
			}
			else
			{
				$data = [
							"success" => "0"
						];
			}

			return Response::json($data);
		}

		return Response::make("The page you requested does not exists!",404);
	}

	public function sessionDestroy()
	{
		Auth::logout();
		return Redirect::to('/');
	}

}
