<?php

use Library\Helpers\Helper;

class UserController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$emp = Auth::user()->card_number;

        $lu = Lastupdate::find(1)->toArray();

        $today = Times::where('sdate','=', date('Y-m-d'))
            ->where('event_card','=', e($emp))
            ->where('doorno','=', 1)
            ->first();
        if (!is_null($today))
        {
            $today = $today->toArray();

            $lu['start_time'] = date('H:i:s', strtotime($today['sdate'] . ' ' . $today['stime']));
            $lu['start_time_string'] = date(DATE_RFC2822, strtotime($today['sdate'] . ' ' . $today['stime']));
        }
        else
        {
            $lu['start_time_string'] = 0;
            $lu['start_time'] = 'No information. Probably not synched yet.';
        }

        $lu['lu_date'] = date('d.m.Y', strtotime($lu['lu_date']));
        $lu['lu_time'] = date('H:i',   strtotime($lu['lu_time']));


        return View::make('user.profile', array('lu' => $lu));
	}

	public function show()
	{
		$emp = Auth::user()->card_number;

		$to = e(Input::get('date_to'));
		$from = e(Input::get('date_from'));

		if($from=="" || strlen($from)==0) $from = date('Y-m-d', mktime(0, 0, 0, date('m'), date('d'), date('Y')));
		else $from = date('Y-m-d', strtotime($from));
		if($to=="" || strlen($to)==0) $to = date('Y-m-d');
		else $to = date('Y-m-d', strtotime($to));

		$times = Times::where('sdate','>=',e($from))
					  ->where('sdate','<=',e($to))
					  ->where('event_card','=',e($emp))
					  ->orderBy('sdate','DESC')
					  ->get();
		
		$info = Helper::manageTimes($times->toArray());

		return Redirect::back()->withInput()->with('times',$info);
	}

	
}
