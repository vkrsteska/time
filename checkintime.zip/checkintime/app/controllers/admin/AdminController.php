<?php namespace controllers\admin;

use View;
use Employees;
use Lastupdate;
use Library\Helpers\Helper;
class AdminController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index($i=0)
	{

		$employees = Employees::all();
        $employees = $employees->sortBy('empname');
        //dd(compact('employees'));

        $lu = Lastupdate::find(1)->toArray();

        $lu['lu_date'] = date('d.m.Y', strtotime($lu['lu_date']));
        $lu['lu_time'] = date('H:i',   strtotime($lu['lu_time']));

		return View::make('admin.dashboard',compact('employees'))->with("interface",$i)->with('lu', $lu);
		
	}

}
