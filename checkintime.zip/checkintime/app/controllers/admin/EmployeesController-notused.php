<?php namespace controllers\admin;

use View;
use Employees;

class EmployeesController extends \BaseController{

	/* List of all employees */

	public function index()
	{
		$employees = Employees::all();
	}

}