<?php namespace controllers\admin;

use Library\Export\PDFExporter;

class ExportController extends \BaseController {

	public function pdfExport(){
		return PDFExporter::export();
	}
}