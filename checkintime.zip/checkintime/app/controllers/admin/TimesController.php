<?php namespace controllers\admin;

use View;
use Times;
use Input;
use Redirect;
use Request;

use Library\Helpers\Helper;
use Library\Export\PDFExporter;
use Excel;

class TimesController extends \BaseController{

	/* get times for employee */

	public function show($exp=false)
	{
        header('Content-type: text/html; charset=utf-8');
//        Session::flush();
//        Session::regenerate();
		$emp = e(Input::get('emp'));
		$to = e(Input::get('date_to'));
		$from = e(Input::get('date_from'));
        $checked = e(Input::get('check'));
        $total = array();

        // echo '<pre>';
        // print_r(Input::all());
        // exit;

		if($from=="" || strlen($from)==0) $from = date('Y-m-d', mktime(0, 0, 0, date('m'), date('d'), date('Y')));
		else $from = date('Y-m-d', strtotime($from));
		if($to=="" || strlen($to)==0) $to = date('Y-m-d');
		else $to = date('Y-m-d', strtotime($to));

        if(Input::get('i')==1)
        {
            if(!$emp || $emp==null || $emp==-1)
            {
                $times = Times::where('sdate','>=',$from)
                    ->where('sdate','<=',$to)
                    ->orderBy('sdate','desc')
                    ->get();
            }
            elseif($emp)
            {
                $times = Times::where('sdate','>=',e($from))
                    ->where('sdate','<=',e($to))
                    ->where('event_card','=',e($emp))
                    ->orderBy('sdate','desc')
                    ->get();
            }
            $data = Helper::manageTimes($times->toArray(), 1);
        }
        else
        {
            if(!$checked) {
                
                if (!$emp || $emp == null || $emp == -1) {
                    $times = Times::where('sdate', '>=', $from)
                        ->where('sdate', '<=', $to)
                        ->orderBy('sdate', 'desc')
                        ->orderBy('emp_name', 'desc')
                        ->get();
                } elseif ($emp) {
                    $times = Times::where('sdate', '>=', e($from))
                        ->where('sdate', '<=', e($to))
                        ->where('event_card', '=', e($emp))
                        ->orderBy('sdate', 'desc')
                        ->orderBy('id', 'asc')
                        ->get();
                    }
                $data = Helper::manageTimes($times->toArray());
                   
            } else {
                
                if(!$emp || $emp == null || $emp == -1){
                    $times = Times::where('sdate', '>=', $from)
                        ->where('sdate', '<=', $to)
                        ->orderBy('sdate', 'desc')
                        ->orderBy('emp_name', 'desc')
                        ->get();
                }
                elseif ($emp) {
                    $times = Times::where('sdate', '>=', e($from))
                        ->where('sdate', '<=', e($to))
                        ->where('event_card', '=', e($emp))
                        ->orderBy('sdate', 'desc')
                        ->orderBy('id', 'asc')
                        ->get();
                    }
                // ako e izbran emp dali ke padne da se staj uslovot vo else pogore treba
                
                $total = array('time' => Helper::manageTotalTimes($times->toArray()), 'check' => '1');
                
                
            }
        }

		$pdf = Input::only('pdfexport');

		if($pdf['pdfexport']!==null) {
            if(!$checked) {
                set_time_limit(0);
                ignore_user_abort(true);
                PDFExporter::export($data,null,$emp,'xls',Input::get('i'));
                return;
                
            } else {
                set_time_limit(0);
                ignore_user_abort(true);
                PDFExporter::exportTotal($total['time'],null,$emp,'xls',Input::get('i'));
                return;
            }
		}

		if(Input::get('i')==1 && !$checked){
            //echo '1';
            //exit;
            return Redirect::route('admin.dashboard',Input::get("i"))->withInput()->with('big_array',$data);
		}
        elseif(Input::get('i')!=1 && $checked==1) {
            //echo '2';
            //exit;
            // checkirano
                return Redirect::route('admin.dashboard',Input::get("i"))->withInput()->with('total', $total);
        }
        else {
            //echo '3';
            //exit;
            // necheckirano
		  return Redirect::route('admin.dashboard',Input::get("i"))->withInput()->with('times',$data);
        }

        return Redirect::route('admin.dashboard',Input::get("i"))->withInput()->with('times',$data);
	}
}