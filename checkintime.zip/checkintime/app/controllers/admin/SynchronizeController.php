<?php namespace controllers\admin;

use Library\Cron\Cron;

use Request;
use Response;
use Lastupdate;

class SynchronizeController extends \BaseController {

    public function sync_all()
    {
        if(Request::ajax())
        {
            $cron = new Cron();
            $sync = $cron->synchronizeAll();

            return Response::make($sync);
        }

        return Response::make('The requested page was not found',404);
    }

    public function sync_times()
    {
        if(Request::ajax())
        {
//            $result = \DB::table('rsa241')->select(\DB::raw('GROUP_CONCAT(id) AS ids, COUNT(*) c'))->groupBy('num')->having('c', '>', '1')->get();
//
//            $return = array();
//            foreach ($result as $r)
//            {
//                $ids = explode(',', $r->ids);
//                array_shift($ids);
//                $return[] = implode(',', $ids);
//            }
//            $return = implode(',', $return);
//            return Response::make($return);

            /////////////////////////////////////

            $cron = new Cron();
            $sync = $cron->synchronizeTimes();

            $lu = Lastupdate::find(1);

			date_default_timezone_set('Europe/Skopje');
            $lu->lu_date = date('Y-m-d');
            $lu->lu_time = date('H:i:s');

            $lu->save();

            return Response::make($sync);
        }

        return Response::make('The requested page was not found',404);
    }

    public function sync_employees()
    {
        if(Request::ajax())
        {
            $cron = new Cron();
            $sync = $cron->synchronizeEmp();

            return Response::make($sync);
        }

        return Response::make('The requested page was not found',404);
    }

}
