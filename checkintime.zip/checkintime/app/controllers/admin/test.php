<?php
error_reporting(E_ALL);


// google autoloader
require_once '../includes/api/google-api-php-client/src/Google/autoload.php';
require_once '../includes/api/google-api-php-client/src/Google/Client.php';
require_once '../includes/api/google-api-php-client/src/Google/Service/YouTube.php';
// amazon autoloader
include_once('../includes/api/aws2/aws-autoloader.php');
include_once('../includes/api/aws2/api-access.php');
session_start();
use Aws\S3\S3Client;

//////////////////////////////////////////////////////////

include('../configuration.php');

$config	= new JConfig();
$option = array();
include('database.php');
$option['host']		= $config->host;
$option['user']		= $config->user;
$option['pass']		= $config->password;
$option['dbname']	= 'lovvvit_live';
$option['dbprefix']	= $config->dbprefix;
$db	= new Database($option);

$query = 'SELECT `deal_video` FROM #__que_live WHERE id = 7032';
$db->setQuery($query);
$db->query();
$result = $db->loadResult();

$videoName = substr($result, 0, -4);

// echo 's3://leo-test-out/'.$videoName.'/'.$videoName.'.mp4';

//////////////////////////////////////////////////////////

$myBucket = 'leo-test-out';

// video file to be uploaded
$streamName = 's3://'.$myBucket.'/'.$videoName.'/'.$videoName.'.mp4';
// video URL
$streamURL = 'http://d4kmsk3mfg00u.cloudfront.net/'.$videoName.'/'.$videoName.'.mp4';
$awsconfig	= new MyAwsConfig();
$s3client = S3Client::factory(array(
    'key'    => $awsconfig->client_id,
    'secret' => $awsconfig->client_secret
));
$s3client->registerStreamWrapper();

$OAUTH2_CLIENT_ID = '501453255172-7ifot087q591irrl8e820rasklckva0g.apps.googleusercontent.com';
$OAUTH2_CLIENT_SECRET = 'wgr6wGveXCBncDb27KbKeZQO';

$client = new Google_Client();
$client->setClientId($OAUTH2_CLIENT_ID);
$client->setClientSecret($OAUTH2_CLIENT_SECRET);


$client->setScopes('https://www.googleapis.com/auth/youtube.upload');
$redirect = 'https://www.lovvv.it/youtube-upload/callback.php';
$client->setRedirectUri($redirect);

$youtube = new Google_Service_YouTube($client);

// Video attributes
$file_title = "test title";
$file_desc = "test desc";

if (isset($_GET['code'])) {
    if (strval($_SESSION['state']) !== strval($_GET['state'])) {
        die('The session state did not match.');
    }
    $client->authenticate($_GET['code']);
    $_SESSION['token'] = $client->getAccessToken();
    header('Location: ' . $redirect);
}
if (isset($_SESSION['token'])) {
    $client->setAccessToken($_SESSION['token']);
}
//Check to ensure that the access token was successfully acquired.
if ($client->getAccessToken()) {
    try{
        $videoPath =$streamName;

        $snippet = new Google_Service_YouTube_VideoSnippet();
        $snippet->setTitle($file_title);
        $snippet->setDescription($file_desc);
        $snippet->setTags(array("tag1", "tag2"));
        $snippet->setCategoryId("24");
        $status = new Google_Service_YouTube_VideoStatus();
        $status->privacyStatus = "private";
        $video = new Google_Service_YouTube_Video();
        $video->setSnippet($snippet);
        $video->setStatus($status);

        $chunkSizeBytes = 1 * 1024 * 1024;

        $client->setDefer(true);

        $insertRequest = $youtube->videos->insert("status,snippet", $video);

        // Create a MediaFileUpload object for resumable uploads.
        $media = new Google_Http_MediaFileUpload(
            $client,
            $insertRequest,
            'video/mp4',
            null,
            true,
            $chunkSizeBytes
        );
        // Get filesize of the video from amazon s3 account
        $head = get_headers($streamURL,1);
        $videoSize = $head['Content-Length'];
        $media->setFileSize($videoSize);
        // Read the media file and upload it chunk by chunk.
        $status = false;
        $handle = fopen($videoPath, "rb");

        while (!$status && !feof($handle))
        {
            $chunk = fread($handle, $chunkSizeBytes);
            $status = $media->nextChunk($chunk);
            echo '<pre>';
            var_dump($status);
            echo '</pre>';
        }
        fclose($handle);
        // If you want to make other calls after the file upload, set setDefer back to false
        $client->setDefer(false);
        echo '<pre>';
        var_dump($status);
        echo '</pre>';

        // $thumbnailUrl = $status['url'];

        // Call the API's channels.list method with mine parameter to fetch authorized user's channel.
        // $listResponse = $youtube->channels->listChannels('brandingSettings', array(
        // 'mine' => 'true',
        // ));

        // $responseChannel = $listResponse[0];
        // $responseChannel['brandingSettings']['image']['bannerExternalUrl']=$thumbnailUrl;

        // Call the API's channels.update method to update branding settings of the channel.
        // $updateResponse = $youtube->channels->update('brandingSettings', $responseChannel);

        // $bannerMobileUrl = $updateResponse["brandingSettings"]["image"]["bannerMobileImageUrl"];

        // $htmlBody .= "<h3>Thumbnail Uploaded</h3><ul>";
        // $htmlBody .= sprintf('<li>%s</li>',
        // $thumbnailUrl);
        // $htmlBody .= sprintf('<img src="%s">', $bannerMobileUrl);
        // $htmlBody .= '</ul>';

    } catch (Google_ServiceException $e) {
        $htmlBody .= sprintf('<p>A service error occurred: <code>%s</code></p>',
            htmlspecialchars($e->getMessage()));
    } catch (Google_Exception $e) {
        $htmlBody .= sprintf('<p>An client error occurred: <code>%s</code></p>',
            htmlspecialchars($e->getMessage()));
    }

    $_SESSION['token'] = $client->getAccessToken();
} else {
    // If the user hasn't authorized the app, initiate the OAuth flow
    $state = mt_rand();
    $client->setState($state);
    $_SESSION['state'] = $state;

    $authUrl = $client->createAuthUrl();
    $htmlBody = <<<END
  <h3>Authorization Required</h3>
  <p>You need to <a href="$authUrl">authorize access</a> before proceeding.<p>
END;
}
