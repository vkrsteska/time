<?php

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

use Library\Export\PDFExporter;

class ExportCommand extends Command {

	/**
	 * The console command name.
	 *
	 * @var string
	 */
	protected $name = 'export';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Synchronizes employees and employee work times.';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Execute the console command.
	 *
	 * @return mixed
	 */
	public function fire()
	{
		$this->info("This may take a while. Please wait...\n");
		$type = $this->argument('type');
		if($type=="pdf"){
			$from = $this->argument('from');
			$to = $this->argument('to');
			if($this->argument('emp'))
				$emp = $this->argument('emp');
			else
				$emp=-1;

			PDFExporter::exportFromCommand($from,$to,$emp);

			$this->info("Export successful!");
		}
	}

	/**
	 * Get the console command arguments.
	 *
	 * @return array
	 */
	protected function getArguments()
	{
		return array(
			 array('type', InputArgument::REQUIRED, 'Set export type (pdf).'),
			 array('from',InputArgument::REQUIRED, 'Set from date.'),
			 array('to',InputArgument::REQUIRED, 'Set to date.'),
			 array('emp',InputArgument::OPTIONAL, 'Set employee card number (Not setting card number will export for all employees).')
		);
	}

	/**
	 * Get the console command options.
	 *
	 * @return array
	 */
	protected function getOptions()
	{
		return array(
			// array('type', null, InputOption::VALUE_REQUIRED, 'Export type', null),
			// array('from', null, InputOption::VALUE_REQUIRED, 'Export from date', null),
			// array('to', null, InputOption::VALUE_REQUIRED, 'Export to date', null),
			// array('emp', null, InputOption::VALUE_REQUIRED, 'Employee card number', null)
		);
	}

}
