<?php

use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;

use LaravelBook\Ardent\Ardent as Ardent;

class User extends Eloquent implements UserInterface, RemindableInterface {

	use UserTrait, RemindableTrait;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table 		= 'users';
	protected $primaryKey 	= 'user_id';

	protected $fillable		= ['card_number','first_name','last_name','email','password','remember_token','deleted_at','code','temp_password','created_at','updated_at'];

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	protected $hidden = array('password', 'remember_token');

	public static $rules = [
			'card_number'		=>	'required|alpha_num',
			'first_name'		=>	'sometimes:required|alpha',
			'last_name'			=>	'sometimes:required|alpha',
			'email'				=>	'required|email|unique:users',
			'password'			=>	'required|min:6',
			'rpt_password'		=>	'required|same:password'
		];

	public $errors;

	public function isValid($data){
		$validation = Validator::make($data,static::$rules);

		if($validation->passes()){
			return true;
		}

		$this->errors = $validation->messages();
		return false;
	}

	public function isAdmin()
	{
		if($this->is_admin)
		{
			return true;
		}

		return false;
	}

	public function employee()
	{
		return $this->belongsTo('Employees','card_number','cardnum');
	}

	public function times()
	{
		return $this->hasMany('Times','emp_id');
	}


	// public static function boot(){
	// 	parent::boot();

	// 	static::created(function($user){
	// 		$emp = new Employees;
	// 		$emp->empid = $user->user_id;
	// 		$emp->empname = $user->first_name." ".$user->last_name;
	// 		$emp->save();
	// 	});
	// }

}
