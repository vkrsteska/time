<?php
	class Lastupdate extends Eloquent{
		protected $table 		= 'last_updated';
        public $timestamps = false;
	}