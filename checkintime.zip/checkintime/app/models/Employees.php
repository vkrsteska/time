<?php
	class Employees extends Eloquent{
		protected $table 		= 'emp';
		protected $primaryKey 	= 'id';
	}