<?php
	class Times extends Eloquent{
		protected $table 		= 'rsa241';
		protected $primaryKey 	= 'num';


	}