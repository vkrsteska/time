<?php

class UserSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		Eloquent::unguard();

		$data = [
					'first_name' 	=> 	'Admin',
					'last_name'		=>	'Admin',
					'email'			=>	'admin@cosmicdevelopment.com',
					'password'		=>	Hash::make('Admin123!'),
					'is_admin'		=>	1,
					'card_number'	=>	"000000000"
				];

		if(User::create($data))
		{
			$this->command->info("User seeded successfuly!");
		}
		else
		{
			$this->command->info("User seeding failed!");
		}
	}

}
