<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/
Route::get("/aa", function(){
	return PDF::html('hello'); 
});
Route::group(['before' => 'guest'], function()
{

	Route::get('/', 'SessionController@index');

	Route::post('/',['as' => 'session.start', 'uses' => 'SessionController@sessionStart' ]);

	Route::get('register', ['as' => 'session.register', 'uses' => 'SessionController@getSessionRegister' ]);
	Route::get('reset_pass', ['as' => 'session.reset_pass_frm', 'uses' => 'SessionController@getResetPasswordForm' ]);
	Route::post('reset_pass', ['as' => 'session.reset_pass_frm', 'uses' => 'SessionController@getResetPasswordForm' ]);
	Route::get('/search_user/{cardnum}', ['uses' => 'SessionController@getUser' ]);
	Route::post('/register', ['as' => 'session.register', 'uses' => 'SessionController@postSessionRegister' ]);

});

Route::group(['before' => 'auth'], function()
{
	Route::get('/profile', ['as' => 'user.profile', 'uses' => 'UserController@index' ]);
	Route::get('/logout', 'SessionController@sessionDestroy');

	Route::post('/times/range', ['as' => 'user.show', 'uses' => 'UserController@show']);
    //TODO: Route::post('/change_pass/', ['as' => 'user.change_pass', 'uses' => 'UserController@changePass']); 

	Route::get('/admin', function(){
		return Redirect::to('/admin/dashboard');
	});

	Route::group(['prefix' => 'admin', 'before' => 'admin'], function(){
        Route::get('/dashboard/{i?}', ['as' => 'admin.dashboard', 'uses' => 'controllers\admin\AdminController@index']);
		Route::post('/dashboard', ['as' => 'times.show', 'uses' => 'controllers\admin\TimesController@show']);
		Route::post('/dashboard', ['as' => 'total.show', 'uses' => 'controllers\admin\TimesController@show']);
        Route::get('/synchronize', ['as' => 'synchronize', 'uses' => 'controllers\admin\SynchronizeController@sync_all']);
        Route::get('/sync_times', ['as' => 'sync_times', 'uses' => 'controllers\admin\SynchronizeController@sync_times']);
        Route::get('/sync_employees', ['as' => 'sync_employees', 'uses' => 'controllers\admin\SynchronizeController@sync_employees']);
		Route::get('/export/{exp}', ['as' => 'pdfexport', 'uses' => 'controllers\admin\TimesController@show']);
	});
});
