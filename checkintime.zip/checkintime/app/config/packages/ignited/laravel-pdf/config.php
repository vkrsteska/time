<?php

return array(
	# Uncomment for 32-bit systems
	#'bin' => base_path() . '/vendor/h4cc/wkhtmltopdf-i386/bin/wkhtmltopdf-i386'
	
	# Uncomment for 64-bit systems
	#'bin' => base_path() . '/vendor/h4cc/wkhtmltopdf-amd64/bin/wkhtmltopdf-amd64'

	# Add any global Wkhtmltopdf options here
	#'no-outline',
	#'margin-top'    => 0,
	#'margin-right'  => 0,
	#'margin-bottom' => 0,
	#'margin-left'   => 0,
);