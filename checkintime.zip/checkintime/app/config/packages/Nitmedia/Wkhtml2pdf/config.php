<?php

return array(

    'debug' => false,
    'binpath' => 'lib/',
	'binfile' => 'wkhtmltopdf-amd64',
	'output_mode' => 'I'
);