@include('layout.header')

@include('layout.main')

@include('layout.footer')