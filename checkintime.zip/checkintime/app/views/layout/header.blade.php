<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>CosmicDevelopment -  CheckIns</title>
    <link rel="stylesheet" href="{{asset('assets/js/jquery-ui/jquery-ui.min.css')}}">
	<link rel="stylesheet" href="{{asset('assets/style/bootstrap/css/bootstrap.min.css')}}">
	<link rel="stylesheet" href="{{asset('assets/style/bootstrap/css/bootstrap-theme.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/style/font-awesome/css/font-awesome.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/style/custom.css')}}">
</head>
<body>
	<div style="margin-top:5%;" class='container'>
        @if(Auth::check())
            <input type="hidden" id="start_time" value="{{@$lu['start_time_string']}}">
            @if(!Auth::user()->isAdmin())
            <div class="row">Your workday started at: <b>{{@$lu['start_time']}}</b>.</div>
            <div class="row">Total time at work (including breaks): <span id="clock" style="font-weight: bold;"></span></div>
            @endif
        @endif
        <div class="row last-synched"><i>Last synched on: <u>{{@$lu['lu_date']}}</u> at <u>{{@$lu['lu_time']}}</u> If you are looking for a time later than that, you won't see it unless you ask Sanja B. to sync the database.</i></div>
		{{---@if(Auth::user()->isAdmin())
			@include('layout.navigation')
		@endif---}}
		<div class="row nav_buttons">
			@if(Auth::check())
					<a href="{{URL::to('/logout')}}" style="float:right;" class='btn btn-default'><i class="fa fa-sign-out"></i> Logout</a>
					@if(Auth::user()->isAdmin())						
						<a style="float:right; margin-right:1%;" class='btn btn-danger' href="{{Request::segment(3)!="" ? URL::route('admin.dashboard') : URL::route('admin.dashboard',1)}}">Interface {{Request::segment(3)!="" ? Request::segment(3) : "0"}}</a>
                        <a href="{{URL::route('sync_employees')}}" style="float:right; margin-right:1%;" class='synchronize btn btn-success'><i class="fa fa-refresh"></i> Synchronize Employees</a>
                        <a href="{{URL::route('sync_times')}}"  style="float:right; margin-right:1%;" class='synchronize btn btn-success'><i class="fa fa-refresh"></i> Synchronize Times</a>
						<div class="sync_info alert alert-info" role="alert" style="float:right; margin-right:1%;">
						</div>
					@endif
				@endif
		</div>
		<div class="row">
				<a href="http://www.cosmicdevelopment.com" target="_blank">
					<img src="{{URL::asset('assets/images/logo.png')}}" alt="CosmicDevelopment">
				</a>
		</div>

		<div style="clear:both"></div>
		@if(Session::has('message_type'))
			<div class="alert alert-{{Session::get('message_type')}}">{{{Session::get('message')}}}</div>
		@endif