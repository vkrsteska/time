	</div>
	<script src="{{asset('assets/js/jquery-1.11.1.min.js')}}"></script>
	<script src="{{asset('assets/js/jquery-ui/jquery-ui.min.js')}}"></script>
	<script src="{{asset('assets/style/bootstrap/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('assets/js/synchronize.js')}}"></script>
    @if(Auth::check())
        <script src="{{asset('assets/js/countdown.min.js')}}"></script>
        <script src="{{asset('assets/js/moment.min.js')}}"></script>
        <script src="{{asset('assets/js/counttime.js')}}"></script>
    @endif
	@yield('scripts')
	
</body>
</html>