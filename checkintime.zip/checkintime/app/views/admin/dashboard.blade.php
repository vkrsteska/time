@extends('main')
<?php header('Content-type: text/html; charset=utf-8'); ?>
@section('content')
	<h1>Cosmic Development -- Work-time records</h1>
	<hr>

	@if($employees->count())
		@include("admin.partials.search_form")

	<div class="row" style="margin-top:4%;">
		
		@if(Session::has('times') || Session::has('big_array'))
			@if(count(Session::get('times')) || count(Session::get('big_array')))
				<h3>Employees' records</h3>
                <div id="total_wrapper" style="font-size: 18px">Total time for selected period (without breaks):&nbsp;&nbsp;<span id="total_time_display" style="font-weight: bold;"></span></div><br/>
				@if($interface==0)
					@include('admin.times')
				@else
					@include('admin.times_2')
				@endif

			@else
				<div class="alert alert-info">
					Не се пронајдени информации според дадените критериуми.
				</div>
			@endif
		
		@elseif(Session::has('total'))
			@if(count(Session::get('total')))
			<h3>Employees' records</h3>
                <div id="total_wrapper" style="font-size: 18px">Total time for selected period All Employees (breaks included):&nbsp;&nbsp;<span id="total_time_display" style="font-weight: bold;"></span></div><br/>
				@if($interface==0)
					@include('admin.total')
				{{-- @else
					@include('admin.times_2') --}}
				@endif
			@else
				<div class="alert alert-info">
					Не се пронајдени информации според дадените критериуми. NO TOTAL
				</div>
			@endif
		@endif
		
	</div>



	@else
		<div class="alert alert-info">
			There are no employees here!
		</div>
	@endif
@stop

@section('scripts')
	<script>
		$(function(){
			$("#from").datepicker({dateFormat: "dd.mm.yy", changeMonth: true, changeYear: true,firstDay: 1});
			$("#to").datepicker({dateFormat: "dd.mm.yy", changeMonth: true, changeYear: true,firstDay: 1});
			//$("#from").attr('readonly','readonly')
			//$("#to").attr('readonly','readonly');
			$("#from").css({'cursor':'pointer'});
			$("#to").css({'cursor':'pointer'});
			
			if($("#from").val()!="")
			{
				$("button[name='pdfexport']").attr('disabled',false);
			}

			$("#from").on("change", function(){
				if($(this).val()!="")
					$("button[name='pdfexport']").attr('disabled',false);
				else
					$("button[name='pdfexport']").attr('disabled',true);
			});
			
			var gt = $('#grand_total').val();
            $('#total_wrapper').html('<h4>Total time for chosen employees (breaks included): </h4>');
            $('#total_wrapper').append('&nbsp;&nbsp;'+ secondsToHms(gt)+'<br/>');
           
            var total_per_emp = $('#total_per_emp').val();
            
            if (total_per_emp != '')
            {
                var obj = jQuery.parseJSON(total_per_emp);

                $('#total_wrapper').html('<h4>Total times per employee</h4>');

                $.each(obj, function(emp, emp_time)
                {
                    $('#total_wrapper').append('<b>'+emp+':</b>&nbsp;&nbsp;'+ secondsToHms(emp_time)+'<br/>');

                });
            }

            function secondsToHms(d) {
				d = Number(d);
				var h = Math.floor(d / 3600);
				var m = Math.floor(d % 3600 / 60);
				var s = Math.floor(d % 3600 % 60);
				
				var day = ((h > 0 ? h + ":" + (m < 10 ? "0" : "") : "0:") + m + ":" + (s < 10 ? "0" : "") + s);
				return day;
			}
			});
	</script>
@stop