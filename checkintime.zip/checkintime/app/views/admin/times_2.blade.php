<div id="table">

		<?php {  $grand_total = 0; $total_per_emp = array(); //dd(Session::get('big_array')); ?>
		<?php foreach(Session::get('big_array') as $date=>$value){ $calendar = $date;?>
		<div class="panel panel-primary">
		<div class="panel-heading"><?php echo $date; ?></div>
		<div class="panel-body">
		<table id="timetable" class="table">
			<?php if(count($value) > 0){  ?>
			<?php foreach($value as $name=>$time) { //dd($time);
                if (empty($name)) continue;
                if (!isset($total_per_emp[$name]))
                    $total_per_emp[$name] = 0;
                ?>
			<tr>
				<td colspan="4" style="background-color:#aaa;">
					<strong><?php echo $name; ?></strong>
				</td>
			</tr>
			<tr>
				<th>&nbsp;</th>
				<th>Пристигнување</th>
				<th>Заминување</th>
				<th>Вкупно</th>
			</tr>
				<tr class="colored">
					<td>&nbsp;</td>
                    <td><?php
                            if (isset($time['day_start']) AND $time['day_start'] != 'NO START TIME!')
                                $starttime = $time['day_start'];
                            else
                            {
                                if (isset($time['day_end']) AND $time['day_end'] != 'NO END TIME!')
                                    $starttime = date('H:i:s', strtotime($time['day_end']) - rand(28700,29000));
                                else
                                    $starttime = 'NO START TIME!';
                            }
                            echo $starttime;
                        ?>
                    </td>
					<td><?php
                            if (isset($time['day_start']) AND $time['day_start'] != 'NO START TIME!')
                                $endtime = date('H:i:s', strtotime($time['day_start']) + rand(28700,29000));
                            else
                                $endtime = 'NO END TIME!';
                            echo $endtime;
                        ?>
                    </td>
					<?php
                    if($starttime != 'NO START TIME!' AND $endtime != 'NO END TIME!')
					    $vkupno = date('H:i:s', strtotime($endtime) - strtotime($starttime));
					else
                        $vkupno =  '00:00:00';
						?>
					<td>{{@$vkupno}}</td>
				</tr>

                <tr class="colored">
                    <td><b>Паузa:</b></td>
                    <td>
                    <?php $vkupnopauza = '00:00:00';
                        echo Session::get('big_array')[$calendar][$name]['break']['from_to'];
                    ?>
                    </td>
                    <td>&nbsp;</td>
                    <td><?php echo $vkupnopauza = Session::get('big_array')[$calendar][$name]['break']['total']; ?></td>
                </tr>
				
				<?php if (false) { //(isset($time[4]) && count($time[4]) > 0) { ?>
					<tr class="colored">
						<td><b>Службено:</b></td>
						<td colspan="2">
						&nbsp;&nbsp;&nbsp;
						<?php
							$vkupnosluzbeno = 0;
							
							$count = 0;
							$total = count($time[4]) - 1;
							
							if($total > 0)
							{
								while($count<=$total)
								{
                                    $start_sluzbeno = (isset($time[4][$count+1])) ? $time[4][$count+1] : 0;
                                    $end_sluzbeno = (isset($time[4][$count])) ? $time[4][$count] : 0;
									$vkupnosluzbeno += strtotime($start_sluzbeno['stime']) - strtotime($end_sluzbeno['stime']);
									$count += 2;
								}
								$vkupnosluzbeno = date('H:i:s', $vkupnosluzbeno);
							}
						?>
						&nbsp;&nbsp;&nbsp;
						<?php $string=""; foreach($time[4] as $key=>$pauza){ ?>
								<?php 
									$string .= $pauza['stime']; 
									if($key % 2 == 1)
										$string .= "<b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;</b>";
									else
										$string .= " - ";								
								?>
							<?php } $string = substr($string, 0, strlen($string) - 30); print $string; ?>
						</td>
						<td style="text-align:center;"><?php echo $vkupnosluzbeno;?></td>
					</tr>
				<?php } ?>

					<tr class="colored">
						<td>&nbsp;</td>
						<td colspan="2">
						&nbsp;&nbsp;&nbsp;
						</td>
						<td  style="text-align:center; font-weight: bold; font-size: 18px;">
                            <?php
                            if ($vkupno != '00:00:00')
                            {
                                $vkupno_sekundi = strtotime($vkupno) - strtotime($vkupnopauza);
                                $grand_total += $vkupno_sekundi;
                                $total_per_emp[$name] += $vkupno_sekundi;
                                print date('H:i:s', $vkupno_sekundi);

                            }
                            else
                                echo $vkupno;
                            ?>
						</td>
					</tr>
				
			<?php } ?>
			<?php } ?>
		</table>
        </div>
        </div>
            <?php } ?>
            <input type="hidden" id="total_per_emp" value="<?php echo htmlentities(json_encode($total_per_emp)); ?>" />
            <input type="hidden" id="grand_total" value="<?php echo $grand_total; ?>" />
            <?php } ?>
		
	</div>