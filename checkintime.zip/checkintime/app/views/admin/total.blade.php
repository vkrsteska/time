<div id="table">

    <?php if(Session::has('total')) { 
        $times = Session::get('total'); 
        $grand_total = new DateTime('00:00:00');  
        $grand_total_clone = clone $grand_total; 
        $total_per_emp = array(); 
        $total = 0;

		function hms($vk) {
			$seconds = 0;
			$seconds += (intval($vk->h) * 3600);
			$seconds += (intval($vk->i) * 60);
			$seconds += (intval($vk->s));
			return $seconds;
		}
        
	?>

    <?php foreach($times['time'] as $date=>$value){ 
    	$dateObj = new DateTime($date); 
    	$date = $dateObj->format('d.m.Y'); 
    	//$date = date('d.m.Y', strtotime($date)); 
    ?>

    <?php if(count($value) > 0):  //dd($value); ?>
    <?php foreach($value as $name=>$time):
        if (empty($name)) continue;
        if (!isset($total_per_emp[$name]))
            $total_per_emp[$name] = 0;
    ?>
         
    <?php
    if ($time['day_start'] != 'NO START TIME!' && $time['day_end'] != 'NO END TIME!') {

        $day_start = new DateTime($time['day_start']);
        $day_end = new DateTime($time['day_end']);
        $vkupno = $day_end->diff($day_start);
        $vkupno_print = $vkupno->format('%H:%I:%S');

    } elseif ($time['day_start'] != 'NO START TIME!' && $time['day_end'] == 'NO END TIME!' AND strtotime($date) == time()) {
        
        $day_start = new DateTime($time['day_start']);
        $now = new DateTime('now');
        $vkupno = $now->diff($day_start);

    } else {
        
        $vkupno = new DateInterval('PT0H0M0S');

    }

    unset($time['day_start'], $time['day_end']);
    $total += hms($vkupno);

    ?>

    <?php endforeach; //($value as $name=>$time) ?>
    <?php endif; //(count($value) > 0) ?>
        
    </div>
    <?php } //echo '<br/> grand_total: '. date('H:i:s', $grand_total);die;  ?>
    <!-- <input type="hidden" id="total_per_emp" value="<?php echo htmlentities(json_encode($total_per_emp)); ?>"/> -->
    <input type="hidden" id="grand_total" value="<?php echo $total; ?>"/> 
    <?php } //dd($total_per_emp);
   ?>
</div>


