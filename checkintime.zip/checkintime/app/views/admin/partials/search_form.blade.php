<div class="row">
	<form action="{{URL::route('times.show')}}" method="POST">
		<div class="row">
			<input type="hidden" value="{{Request::segment(3)!="" ? 1 : ''}}" name="i" />
			<div class="col-md-3">
                <input type="text" name="date_from" id="from" class="form-control" placeholder="Choose date from" value="{{ Input::old('date_from') ? Input::old('date_from') : date('d.m.Y'); }}">
                <?php //<input type="text" name="date_from" id="from" class="form-control" placeholder="Choose date from" value="{{ date('Y-m') }}-01"> ?>
			</div>

			<div class="col-md-3">
                <input type="text" name="date_to" id="to" class="form-control" placeholder="Choose date to" value="{{ Input::old('date_to') ? Input::old('date_to') :  date('d.m.Y'); }}">
                <?php //<input type="text" name="date_to" id="to" class="form-control" placeholder="Choose date to"  value="{{ date('Y-m-d') }}"> ?>
			</div>

			<div class="col-md-3">
				<select name="emp" class="form-control">
					<option value="-1">--- Сите вработени ---</option>
					@foreach($employees as $emp)
                        @if (!empty($emp->cardnum))
						<option value="{{{ $emp->cardnum }}}" @if($emp->cardnum == Input::old('emp')) selected @endif>
							{{{ $emp->empname }}}
						</option>
                        @endif
					@endforeach
				</select>
			</div>

			<div class="col-md-3">
				<button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-search"></i> Show records</button>
				<button type="submit" name="pdfexport" style="margin-right:1%;" class='btn btn-info' disabled><i class="fa fa-download"></i> Excel</button>
			</div>
		</div>
		<div class="row">
			<input type="hidden" name="j" />
			<div class="col-md-3">
				@if(Session::has('total'))
						@if(isset($total['check']))
							{{ Form::checkbox('check', 1, true) }}
						@else
							{{ Form::checkbox('check', 1) }}
						@endif
				@else
				 	{{ Form::checkbox('check', 1) }}
				@endif
				Total time 
			</div>
		</div>
	</form>
</div>

