<div id="table">

		<?php { if(Session::has('times')) $times = Session::get('times'); else $times = $times_exp;?>
		<?php foreach($times as $date=>$value){ ?>
		<div class="panel panel-primary">
		<div class="panel-heading"><?php echo $date; ?></div>
		<div class="panel-body">
		<table id="timetable" class="table">
			<?php if(count($value) > 0){ ?>
			<?php foreach($value as $name=>$time) {?>
			<tr>
				<td colspan="4" style="background-color:#aaa;">
					<strong><?php echo $name; ?></strong>
				</td>
			</tr>
			<tr>
				<th>&nbsp;</th>
				<th>Пристигнување</th>
				<th>Заминување</th>
				<th>Вкупно</th>
			</tr>
				<?php //foreach($time as $key=>$val){ ?>
				<tr class="colored">
					<td>&nbsp;</td>
					<td><?php echo @$time[1][0]['stime']; ?></td>
					<td ><?php echo @$time[2][count($time[2])-1]['stime']; ?></td>
					<?php if(isset($time[1][0]['stime']) && isset($time[2][@count($time[2])-1]['stime'])) 
						$vkupno = date('H:i:s', strtotime(@$time[2][@count($time[2])-1]['stime']) - strtotime(@$time[1][0]['stime']));
						else $vkupno =  '-';
						?>
					<td><?php echo @$vkupno; ?></td>
				</tr>
				<?php //} ?>
				
				<?php if(isset($time[3]) && count($time[3]) > 0) { ?>
					<tr class="colored">
						<td><b>Паузи:</b></td>
						<td>
						&nbsp;&nbsp;&nbsp;
						<?php
							$vkupnopauza = 0;
							
							$count = 0;
							$total = count($time[3]) - 1;
							
							if($total > 0)
							{
								while($count<=$total)
								{
									if(isset($time[3][$count+1]['stime']) && isset($time[3][$count]['stime']))
									{
										if($time[3][$count+1]['stime'] > $time[3][$count]['stime'])
										{
											$vkupnopauza += strtotime(@$time[3][$count+1]['stime']) - strtotime(@$time[3][$count]['stime']);
										}
										else
										{
											$vkupnopauza += strtotime(@$time[3][$count]['stime']) - strtotime(@$time[3][$count+1]['stime']);
										}										
									}
									$count += 2;
								}
								$vkupnopauza = date('H:i:s', $vkupnopauza);
							}
						?>

						<?php $string="";  foreach($time[3] as $key=>$pauza){ ?>
								<?php 
									$string .= $pauza['stime']; 
									if($key % 2 == 1)
										$string .= "<b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;</b>";
									else
										$string .= " - ";								
								?>
							<?php } $string = substr($string, 0, strlen($string) - 35); print $string; ?>
						</td>
						<td>&nbsp;</td>
						<td><?php echo $vkupnopauza;?></td>
					</tr>
				<?php } ?>
				
				<?php if (false) { //(isset($time[4]) && count($time[4]) > 0) { ?>
					<tr class="colored">
						<td><b>Службено:</b></td>
						<td colspan="2">
						&nbsp;&nbsp;&nbsp;
						<?php
							$vkupnosluzbeno = 0;
							
							$count = 0;
							$total = count($time[4]) - 1;
							
							if($total > 0)
							{
								while($count<=$total)
								{
									$vkupnosluzbeno += strtotime(@$time[4][$count+1]['stime']) - strtotime(@$time[4][$count]['stime']);
									$count += 2;
								}
								$vkupnosluzbeno = date('H:i:s', $vkupnosluzbeno);
							}
						?>
						&nbsp;&nbsp;&nbsp;
						<?php $string=""; foreach($time[4] as $key=>$pauza){ ?>
								<?php 
									$string .= $pauza['stime']; 
									if($key % 2 == 1)
										$string .= "<b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;</b>";
									else
										$string .= " - ";								
								?>
							<?php } $string = substr($string, 0, strlen($string) - 30); print $string; ?>
						</td>
						<td style="text-align:center;"><?php echo $vkupnosluzbeno;?></td>
					</tr>
				<?php } ?>

					<tr class="colored">
						<td>&nbsp;</td>
						<td colspan="2">
						&nbsp;&nbsp;&nbsp;
						</td>
						<td  style="text-align:center; font-weight: bold; font-size: 18px;">
							<?php if(isset($time[3]) && count($time[3]) > 0) {?>
							<?php if($vkupno != 0 && $vkupno != '-') print date('H:i:s', strtotime($vkupno) - strtotime($vkupnopauza)); ?>
							<?php } else { 
								print date('H:i:s', strtotime($vkupno));
							} ?>
						</td>
					</tr>
				
			<?php } ?>
			<?php } ?>
		</table></div>
		</div> <?php }} ?>
		
	</div>