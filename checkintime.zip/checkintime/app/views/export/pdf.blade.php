<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Excel</title>
    <link rel="stylesheet" type="text/css" href="{{asset('assets/style/export.css')}}">
</head>
<body style="margin-left:100px;">
<?php   $grand_total = 0;  
        $total_per_emp = $dates = array(); 
        //h:i:s to seconds
        function hms($vk) {
            $seconds = 0;
            $seconds += (intval($vk->h) * 3600);
            $seconds += (intval($vk->i) * 60);
            $seconds += (intval($vk->s));
            return $seconds;
        }; ?>
<?php   //seconds to h:i:s
        function secTohms($seconds) {
            $t = round($seconds);
            return sprintf('%02d:%02d:%02d', ($t/3600),($t/60%60), $t%60);
        } ?>

    <table id="timetable">
        <tr><td colspan="4"><h1>Извештај за работно време - {{@$name}}</h1></td></tr>

    
    <?php foreach($times as $date=>$value){ 
        $dateObj = new DateTime($date); 
        $date = $dateObj->format('d.m.Y'); 
        //$date = date('d.m.Y', strtotime($date)); 
        $dates[] = $date; ?>

        <?php if(count($value) > 0): ?>
        <?php foreach($value as $empname=>$time):
            if (empty($empname)) continue;
            if (!isset($total_per_emp[$empname]))
                $total_per_emp[$empname] = 0; ?>

        <tr>
            <td style="background-color:#aaa;">
                <h3><?php if ($name == 'СИТЕ ВРАБОТЕНИ') echo $empname; ?></h3>
            </td>
            <td colspan="3" style="background-color:#aaa;">
                <h3><?php echo $date; ?></h3>
            </td>
        </tr>
        <tr>
            <th width="20px;">&nbsp;</th>
            <th style="text-align:left; width:20px;">Пристигнување</th>
            <th style="text-align:left; width:20px;">Заминување</th>
            <th style="text-align:left; width:20px;">Вкупно</th>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td> {{@$time['day_start']}}</td>
            <td>{{@$time['day_end']}}</td>
            <?php

                    //if (!isset($time['day_start'])) dd($time);
                    if ($time['day_start'] != 'NO START TIME!' && $time['day_end'] != 'NO END TIME!') {
                        //$vkupno = date('H:i:s', strtotime($time['day_end']) - strtotime($time['day_start']) - 3600);
                        $day_start = new DateTime($time['day_start']);
                        $day_end = new DateTime($time['day_end']);
                        $vkupno = $day_end->diff($day_start);
                        $vkupno_print = $vkupno->format('%H:%I:%S');
                    } elseif ($time['day_start'] != 'NO START TIME!' && $time['day_end'] == 'NO END TIME!' AND strtotime($date) == time()) {
                        //$vkupno = date('H:i:s', strtotime('-1 hours') - strtotime($time['day_start']));
                        // $vkupno = date('H:i:s', time() - strtotime($time['day_start']));

                        $day_start = new DateTime($time['day_start']);
                        $now = new DateTime('now');
                        $vkupno = $now->diff($day_start);
                        $vkupno_print = $vkupno->format('%H:%I:%S');

                    } else {
                        $vkupno_print = '00:00:00';
                        $vkupno = new DateInterval('PT0H0M0S');
                    }
                    unset($time['day_start'], $time['day_end']);

                    ?>
            <td>{{@$vkupno_print}}</td>
        </tr>
        <?php //if(isset($time[3]) && count($time[3]) > 0) { ?>
        <tr class="colored">
            <td><b>Паузи:</b></td>
            <td colspan="2" style="text-align:left;" width="100">
                <?php
//                        $vkupnopauza = new DateTime('00:00:00');

                        $string = "";
                        $breaks = array();
                        foreach ($time AS $key => $arr) {
                            if (!in_array((int)$arr['doorno'], array(3, 4)))
                                continue;
                            $breaks[] = $arr;
                        }

                        //$vkupnopauza = new DateTimeImmutable;
                        $vkupnopauza = new DateTime('00:00:00');
                        $vkupnopauza_clone = clone $vkupnopauza;

                        foreach ($breaks AS $key => $arr)
                        {
                            if ((int)$arr['doorno'] == 3)
                            {
                                $pauza_start = new DateTime($arr['stime']);
                                $pauza_start_print = $arr['stime'];

                                if (isset($breaks[$key + 1]['stime']) AND $breaks[$key + 1]['doorno'] == 4) {

                                    $pauza_end = new DateTime($breaks[$key + 1]['stime']);
                                    $pauza_end_print = $breaks[$key + 1]['stime'];

                                    $pauza = $pauza_start->diff($pauza_end);
                                    $vkupnopauza_clone = $vkupnopauza_clone->add($pauza);

                                } else
                                    $pauza_end_print = '<b><span style="color:red;">???</span></b>';

                                $string .= $pauza_start_print . ' - ' . $pauza_end_print . '<b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;</b>';
                            }
                        }

                        $vkupnopauza_interval = $vkupnopauza->diff($vkupnopauza_clone);
                        $vkupnopauza_print = $vkupnopauza_interval->format("%H:%I:%S");

                        $string = substr($string, 0, strlen($string) - 44); print $string;

                        ?>
            </td>
            <td style="text-align:left;">{{@$vkupnopauza_print}}</td>
        </tr>

        <?php if (false) { //(isset($time[4]) && count($time[4]) > 0) { ?>
        <tr class="colored">
            <td><b>Службено:</b></td>
            <td colspan="2">
                &nbsp;&nbsp;&nbsp;
                <?php
                $vkupnosluzbeno = 0;

                $count = 0;
                $total = count($time[4]) - 1;

                if ($total > 0) {
                    while ($count <= $total) {
                        $vkupnosluzbeno .= strtotime($time[4][$count + 1]['stime']) - strtotime($time[4][$count]['stime']);
                        $count += 2;
                    }
                    $vkupnosluzbeno = date('H:i:s', $vkupnosluzbeno);
                }
                ?>
                &nbsp;&nbsp;&nbsp;
                <?php $string = ""; foreach($time[4] as $key=>$pauza) { ?>
                <?php
                $string .= $pauza['stime'];
                if ($key % 2 == 1)
                    $string .= "<b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;</b>";
                else
                    $string .= " - ";
                ?>
                <?php } $string = substr($string, 0, strlen($string) - 44); print $string; ?>
            </td>
            <td style="text-align:left;">{{@$vkupnosluzbeno}}</td>
        </tr>
        <?php } ?>

        <tr class="colored">
            <td>&nbsp;</td>
            <td colspan="2">
                &nbsp;&nbsp;&nbsp;
            </td>
            <td style="text-align:left; font-weight: bold; font-size: 18px;">
                <?php

                        if ($vkupno !== new DateInterval('PT0H0M0S')) {
                            $e = new DateTime('00:00:00');
                            $e_clone = clone $e;
                            $e_clone = $e_clone->add($vkupno);
                            //var_dump($vkupno);

                            if ($vkupnopauza_clone != new DateTime('00:00:00')) {

                                if($e_clone != new DateTime('00:00:00')) {
 
                                    $e_clone->add($vkupnopauza_interval);
                                    $vkupno_sekundi = $e_clone->diff($e);

                                } else {
                                    
                                    $vkupno_sekundi = $vkupno;
                                    
                                }
                                //echo 'here1<br/>';
                                //var_dump($vkupnopauza_interval);
                            } else {

                                $vkupno_sekundi = $e_clone->diff($e);
                                //echo 'here2<br/>';
                                //var_dump($vkupno_sekundi);
                            }
                            //$vkupno_sekundi = $vkupno;

                            

                            //var_dump($grand_total);die;
                            $temp = new DateTime($vkupno_sekundi->h.':'.$vkupno_sekundi->i.':'.$vkupno_sekundi->s);
                            
                            $total_per_emp[$empname] += hms($vkupno_sekundi);
                            print $vkupno_sekundi->format('%H:%I:%S');

                            //print date('H:i:s', $vkupno_sekundi);

                        } else
                            echo $vkupno_print;
                            //$total_per_emp[$name] += $temp->format('U');
                        ?>
            </td>
        </tr>

        <?php endforeach; //($value as $name=>$time) ?>
                
                <?php endif; //(count($value) > 0) ?>
                
        <?php }  ?>
        <tr>
            <th colspan="2" style="font-size: 18px">Вкупно време за периодот од <?php echo date('d.m.Y', strtotime(min($dates))).' до '.date('d.m.Y', strtotime(max($dates))); ?> по вработен (без вклучени паузи):</th>
        </tr>
        <?php foreach ($total_per_emp as $empname => $emptime): ?>
        <tr>
            <td style="font-weight: bold;"><?php echo $empname; ?>&nbsp;&nbsp;</td><td><?php echo secTohms($emptime); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>