<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Excel</title>
	<link rel="stylesheet" type="text/css" href="{{asset('assets/style/export.css')}}">
</head>
<body style="margin-left:100px;">

<h1>Извештај за работно време - {{$name}}</h1>

<div style="width:100%;">
		<?php { $times = $times_exp;?>
		<?php foreach($times as $date=>$value){ ?>
		
		<table id="timetable">
			<?php if(count($value) > 0){ ?>
			<?php foreach($value as $name=>$time) {?>
			<tr>
				<td colspan="4" style="background-color:#aaa;">
					<h3><?php echo $date; ?></h3>
				</td>
			</tr>
			<tr>
				<th width="20px;">&nbsp;</th>
				<th style="text-align:left; width:20px; ">Пристигнување</th>
				<th style="text-align:left; width:20px; ">Заминување</th>
				<th style="text-align:left; width:20px; ">Вкупно</th>
			</tr>
				<tr>
					<td>&nbsp;</td>
					<td ><?php echo @$time[1][0]['stime']; ?></td>
					<td ><?php echo @$time[2][count($time[2])-1]['stime']; ?></td>
					<?php if(isset($time[1][0]['stime']) && isset($time[2][@count($time[2])-1]['stime'])) 
						$vkupno = date('H:i:s', strtotime(@$time[2][@count($time[2])-1]['stime']) - strtotime(@$time[1][0]['stime']));
						else $vkupno =  '-';
						?>
					<td ><?php echo @$vkupno; ?></td>
				</tr>
				<?php if(isset($time[3]) && count($time[3]) > 0) { ?>
					<tr class="colored">
						<td><b>Паузи:</b></td>
						<td colspan="2" style="text-align:left;" width="100">
						<?php
							$vkupnopauza = 0;
							
							$count = 0;
							$total = count($time[3]) - 1;
							
							if($total > 0)
							{
								while($count<=$total)
								{
									if(isset($time[3][$count+1]['stime']) && isset($time[3][$count]['stime']))
									{
										if($time[3][$count+1]['stime'] > $time[3][$count]['stime'])
										{
											$vkupnopauza += strtotime(@$time[3][$count+1]['stime']) - strtotime(@$time[3][$count]['stime']);
										}
										else
										{
											$vkupnopauza += strtotime(@$time[3][$count]['stime']) - strtotime(@$time[3][$count+1]['stime']);
										}										
									}
									$count += 2;
								}
								$vkupnopauza = date('H:i:s', $vkupnopauza);
							}
						?>

						<?php $string="";  foreach($time[3] as $key=>$pauza){ ?>
								<?php 
									$string .= $pauza['stime']; 
									if($key % 2 == 1)
										$string .= "<b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;</b>";
									else
										$string .= " - ";								
								?>
							<?php } $string = substr($string, 0, strlen($string) - 35); print $string; ?>
						</td>
						
						<td  style="text-align:left;"><?php echo $vkupnopauza;?></td>
					</tr>
				<?php } ?>
				
				<?php if(isset($time[4]) && count($time[4]) > 0) { ?>
					<tr class="colored">
						<td><b>Службено:</b></td>
						<td colspan="2">
						&nbsp;&nbsp;&nbsp;
						<?php
							$vkupnosluzbeno = 0;
							
							$count = 0;
							$total = count($time[4]) - 1;
							
							if($total > 0)
							{
								while($count<=$total)
								{
									$vkupnosluzbeno += strtotime(@$time[4][$count+1]['stime']) - strtotime(@$time[4][$count]['stime']);
									$count += 2;
								}
								$vkupnosluzbeno = date('H:i:s', $vkupnosluzbeno);
							}
						?>
						&nbsp;&nbsp;&nbsp;
						<?php $string=""; foreach($time[4] as $key=>$pauza){ ?>
								<?php 
									$string .= $pauza['stime']; 
									if($key % 2 == 1)
										$string .= "<b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;</b>";
									else
										$string .= " - ";								
								?>
							<?php } $string = substr($string, 0, strlen($string) - 30); print $string; ?>
						</td>
						<td style="text-align:left;"><?php echo $vkupnosluzbeno;?></td>
					</tr>
				<?php } ?>

					<tr class="colored">
						<td>&nbsp;</td>
						<td colspan="2">
						&nbsp;&nbsp;&nbsp;
						</td>
						<td  style="text-align:left; font-weight: bold; font-size: 18px;">
							<?php if(isset($time[3]) && count($time[3]) > 0) {?>
							<?php if($vkupno != 0 && $vkupno != '-') print date('H:i:s', strtotime($vkupno) - strtotime($vkupnopauza)); ?>
							<?php } else { 
								print date('H:i:s', strtotime($vkupno));
							} ?>
						</td>
					</tr>
				
			<?php } ?>
			<?php } ?>
		</table> <?php }} ?>
		
	</div>
</body>
</html>