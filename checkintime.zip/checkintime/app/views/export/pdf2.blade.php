<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Excel</title>
    <link rel="stylesheet" type="text/css" href="{{asset('assets/style/export.css')}}">
</head>
<body style="margin-left:100px;">
<?php $grand_total = 0;  $total_per_emp = array(); ?>
<h1>Извештај за работно време - {{$name}}</h1>

<div style="width:100%;">
    <?php foreach($times as $date=>$value) { ?>

    <table id="timetable">
        <?php if(count($value) > 0) {  ?>
        <?php foreach($value as $empname=>$time) {
            if (empty($empname)) continue;
            if (!isset($total_per_emp[$empname]))
                $total_per_emp[$empname] = 0; ?>
        <tr>
            <td colspan="4" style="background-color:#aaa;">
                <strong><?php echo $date; if ($name == 'сите вработени') echo ' - ' . $empname; ?></strong>
            </td>
        </tr>
        <tr>
            <th width="20px;">&nbsp;</th>
            <th style="text-align:left; width:20px;">Пристигнување</th>
            <th style="text-align:left; width:20px;">Заминување</th>
            <th style="text-align:left; width:20px;">Вкупно</th>
        </tr>
        <tr class="colored">
            <td>&nbsp;</td>
            <td>
                <?php
                if (isset($time['day_start']) AND $time['day_start'] != 'NO START TIME!')
                    $starttime = $time['day_start'];
                else {
                    if (isset($time['day_end']) AND $time['day_end'] != 'NO END TIME!')
                        $starttime = date('H:i:s', strtotime($time['day_end']) - rand(28700, 29000));
                    else
                        $starttime = 'NO START TIME!';
                }
                echo $starttime;
                ?>
            <td>
                <?php
                if (isset($time['day_start']) AND $time['day_start'] != 'NO START TIME!')
                    $endtime = date('H:i:s', strtotime($time['day_start']) + rand(28700, 29000));
                else
                    $endtime = 'NO END TIME!';
                echo $endtime;
                ?>
            </td>
            <?php
            if ($starttime != 'NO START TIME!' AND $endtime != 'NO END TIME!')
                $vkupno = date('H:i:s', strtotime($endtime) - strtotime($starttime));
            else
                $vkupno = '00:00:00';
            ?>
            <td><?php echo $vkupno; ?></td>
        </tr>

        <tr class="colored">
            <td><b>Пауза:</b></td>
            <td style="text-align:left;" width="100">
                <?php $vkupnopauza = '00:00:00';
                echo $time['break']['from_to'];
                ?>
            </td>
            <td>&nbsp;</td>
            <td><?php echo $vkupnopauza = $time['break']['total']; ?></td>
        </tr>

        <?php if (false) { //(isset($time[4]) && count($time[4]) > 0) { ?>
        <tr class="colored">
            <td><b>Службено:</b></td>
            <td colspan="2">
                &nbsp;&nbsp;&nbsp;
                <?php
                $vkupnosluzbeno = 0;

                $count = 0;
                $total = count($time[4]) - 1;

                if ($total > 0) {
                    while ($count <= $total) {
                        $vkupnosluzbeno += strtotime($time[4][$count + 1]['stime']) - strtotime($time[4][$count]['stime']);
                        $count += 2;
                    }
                    $vkupnosluzbeno = date('H:i:s', $vkupnosluzbeno);
                }
                ?>
                &nbsp;&nbsp;&nbsp;
                <?php $string = ""; foreach($time[4] as $key=>$pauza) { ?>
                <?php
                $string .= $pauza['stime'];
                if ($key % 2 == 1)
                    $string .= "<b>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;</b>";
                else
                    $string .= " - ";
                ?>
                <?php } $string = substr($string, 0, strlen($string) - 30); print $string; ?>
            </td>
            <td style="text-align:center;"><?php echo $vkupnosluzbeno;?></td>
        </tr>
        <?php } ?>

        <tr class="colored">
            <td>&nbsp;</td>
            <td colspan="2">
                &nbsp;&nbsp;&nbsp;
            </td>
            <td style="text-align:left; font-weight: bold; font-size: 18px;">
                <?php
                if ($vkupno != '00:00:00')
                {
                    $vkupno_sekundi = strtotime($vkupno) - strtotime($vkupnopauza);
                    $grand_total += $vkupno_sekundi;
                    $total_per_emp[$empname] += $vkupno_sekundi;
                    print date('H:i:s', $vkupno_sekundi);

                }
                else
                    echo $vkupno;
                ?>
            </td>
        </tr>

        <?php } ?>
        <?php } ?>
    </table>
        <?php } ?>
    <table>
        <tr>
            <th style="font-size: 18px">Вкупно време за периодот од <?php echo date('d.m.Y', strtotime(min($dates))).' до '.date('d.m.Y', strtotime(max($dates))); ?> по вработен (без вклучени паузи):</th>
        </tr>
        <?php foreach ($total_per_emp as $empname => $emptime): ?>
        <tr>
            <td style="font-weight: bold;"><?php echo $empname; ?>&nbsp;&nbsp;</td><td><?php echo Library\Helpers\Helper::rectime($emptime); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <?php  ?>
</div>
</body>
</html>