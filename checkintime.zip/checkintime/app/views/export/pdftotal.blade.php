<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Excel</title>
    <link rel="stylesheet" type="text/css" href="{{asset('assets/style/export.css')}}">
</head>
<body style="margin-left:100px;">
    <?php    
        $grand_total = new DateTime('00:00:00');  
        $grand_total_clone = clone $grand_total; 
        $total = 0;
        $total_per_emp = $dates = array(); 

        //h:i:s to seconds
        function hms($vk) {
            $seconds = 0;
            $seconds += (intval($vk->h) * 3600);
            $seconds += (intval($vk->i) * 60);
            $seconds += (intval($vk->s));
            return $seconds;
        }; ?>

    <?php   //seconds to h:i:s
        function secTohms($seconds) {
            $t = round($seconds);
            return sprintf('%02d:%02d:%02d', ($t/3600),($t/60%60), $t%60);
        } ?>

<h1>Извештај за работно време - {{@$name}}</h1>

<div style="width:100%;">
    
    <?php foreach($times as $date=>$value){ 
        $dateObj = new DateTime($date); 
        $date = $dateObj->format('d.m.Y');
        $dates[] = $date; 
        //$date = date('d.m.Y', strtotime($date)); 
    ?>

    <table id="timetable">
        <?php if(count($value) > 0):  //dd($value); ?>
            <?php foreach($value as $name=>$time):
            if (empty($name)) continue;
                if (!isset($total_per_emp[$name]))
                    $total_per_emp[$name] = 0;
        ?>
        
        <?php
            if ($time['day_start'] != 'NO START TIME!' && $time['day_end'] != 'NO END TIME!') {

                $day_start = new DateTime($time['day_start']);
                $day_end = new DateTime($time['day_end']);
                $vkupno = $day_end->diff($day_start);
                $vkupno_print = $vkupno->format('%H:%I:%S');

            } elseif ($time['day_start'] != 'NO START TIME!' && $time['day_end'] == 'NO END TIME!' AND strtotime($date) == time()) {
            
                $day_start = new DateTime($time['day_start']);
                $now = new DateTime('now');
                $vkupno = $now->diff($day_start);

            } else {

                $vkupno = new DateInterval('PT0H0M0S');
            }

            unset($time['day_start'], $time['day_end']);
            $total += hms($vkupno);
        ?>
            <?php endforeach; //($value as $name=>$time) ?>
        <?php endif; //(count($value) > 0) ?>
    </table>  
    <?php  ?>
    <?php } ?>
    <table> 
        <tr>
        <th style="font-size: 18px">Вкупно време за периодот од <?php echo date('d.m.Y', strtotime(min($dates))).' до '.date('d.m.Y', strtotime(max($dates))); ?></th>
        </tr>
        <tr>
            <td style="font-weight: bold;"><?php echo 'Вкупно време (со вклучени паузи):'; ?>&nbsp;&nbsp;<?php echo secTohms($total); ?></td>
        </tr>
    </table>
</div>
</body>
</html>