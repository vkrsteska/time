@extends('main')

@section('content')
    <?php //dd(Auth::user()); ?>
	<h1>Info - {{Auth::user()->employee->empname}}</h1>
	<div class="row">
		<form action="{{URL::route('user.show')}}" method="POST">
			<div class="row">
				<div class="col-md-3">
					<input type="text" name="date_from" id="from" class="form-control" placeholder="Choose date from" value="{{ Input::old('date_from') ? Input::old('date_from') : date('d.m.Y'); }}">
				</div>

				<div class="col-md-3">
					<input type="text" name="date_to" id="to" class="form-control" placeholder="Choose date to" value="{{ Input::old('date_to') ? Input::old('date_to') :  date('d.m.Y'); }}">
				</div>
				<div class="col-md-3">
					<button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-search"></i> Show records</button>
				</div>
			</div>
		</form>
	</div>
	<hr>
	@if(Session::has('times') && count(Session::get('times')))
        <div style="font-size: 18px">Total time for selected period (without breaks):&nbsp;&nbsp;<span id="total_time_display" style="font-weight: bold;"></span></div><br/>
		@include('user.times',['times' => Session::get('times')])
	@endif
@stop

@section('scripts')
	<script>
		$(function(){
            $("#from").datepicker({dateFormat: "dd.mm.yy", changeMonth: true, changeYear: true,firstDay: 1});
            $("#from").datepicker( "option", "defaultDate", +7 );
            $("#to").datepicker({dateFormat: "dd.mm.yy", changeMonth: true, changeYear: true,firstDay: 1});
			//$("#from").attr('readonly','readonly')
			//$("#to").attr('readonly','readonly');
			$("#from").css({'cursor':'pointer'});
			$("#to").css({'cursor':'pointer'});


            // $('#total_time_display').html(rectime($('#grand_total').val()));
            $('#total_time_display').html($('#grand_total').val());

            function rectime(secs) {
                
                var hr = Math.floor(secs / 3600);
                var min = Math.floor((secs - (hr * 3600))/60);
                var sec = secs - (hr * 3600) - (min * 60);

                if (hr < 10) {hr = "0" + hr; }
                if (min < 10) {min = "0" + min;}
                if (sec < 10) {sec = "0" + sec;}
                if (hr == "0") {hr = "00";}
                return hr + ':' + min + ':' + sec;
            }
		});
	</script>
@stop