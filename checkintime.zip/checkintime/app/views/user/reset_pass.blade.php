@extends('main')

@section('content')
<!--
    @if(Session::has('message_type'))
        <div class="alert alert-{{Session::get('message_type')}}">{{{Session::get('message')}}}</div>
    @endif
-->
<div class='well col-md-6'>
    @if(!Session::has('token'))
        <h1>Reset Password Form</h1>
	@else
        <h1>Enter New Pwd for {{ $email }}</h1>
    @endif
    <form action="{{URL::route('session.reset_pass_frm')}}" method="post">
		@if(!Session::has('token'))
        <div class="form-group">
			<input type="email" name="email" placeholder="Email" class="form-control">
			{{$errors->first('email')}}
		</div>
        @else
		<div class="form-group">
			<input type="password" name="password" placeholder="Password" class="form-control">
			{{$errors->first('password')}}
		</div>

		<div class="form-group">
			<input type="password" name="rpt_password" placeholder="Repeat password" class="form-control">
			{{$errors->first('rpt_password')}}
		</div>
        @endif
		<div class="form-group">
        @if(!Session::has('token'))
			<input type="submit" name="submit_form" value="Send password reset link" class="btn btn-primary">
        @else
         	<input type="submit" name="submit_form" value="Register" class="btn btn-primary">
        @endif
			<input type="reset" value="Clear" class="btn btn-default">
			<a href="{{URL::action('SessionController@index')}}" class="btn btn-default" style="float:right;"><i class="fa fa-reply"></i> Back</a>
		</div>
		{{Form::token()}}
	</form>
</div>
@stop

@section('scripts')
	<script type="text/javascript">
		var cardnum = $("input[name='card_number']");

		cardnum.on("focusout", function(){
			$.ajax({
				url: "search_user/"+$(this).val(),
				dataType: 'json',
				type: 'get',
				success: function(user){
					if(user.success==1)
					{
						$("input[name='first_name']").val(user.first_name);
						$("input[name='last_name']").val(user.last_name);
						return true;
					}
					else
					{
						alert("The card number you entered is not valid or doesn't exists!");
						cardnum.focus();
						return false;
					}
				}
			});
		});
	</script>
@stop