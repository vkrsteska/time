@extends('main')

@section('content')
<div class='well col-md-6'>
	<h1>Register</h1>
	<form action="{{URL::route('session.register')}}" method="post">
		<div class="form-group">
			<input type="text" name="card_number" placeholder="Card number" class="form-control" {{ Input::old('card_number') ? 'value="'.Input::old('card_number').'"' : ""   }}>
			{{$errors->first('card_number')}}
		</div>

		<div class="form-group">
			<input type="text" name="first_name" placeholder="First name" class="form-control" {{ Input::old('first_name') ? 'value="'.Input::old('first_name').'"' : ""   }} disabled>
			{{$errors->first('fname')}}
		</div>

		<div class="form-group">
			<input type="text" name="last_name" placeholder="Last name" class="form-control" {{ Input::old('last_name') ? 'value="'.Input::old('last_name').'"' : ""   }} disabled>
			{{$errors->first('lname')}}
		</div>

		<div class="form-group">
			<input type="email" name="email" placeholder="Email" class="form-control" {{ Input::old('email') ? 'value="'.Input::old('email').'"' : ""   }}>
			{{$errors->first('email')}}
		</div>

		<div class="form-group">
			<input type="password" name="password" placeholder="Password" class="form-control">
			{{$errors->first('password')}}
		</div>

		<div class="form-group">
			<input type="password" name="rpt_password" placeholder="Repeat password" class="form-control">
			{{$errors->first('rpt_password')}}
		</div>

		<div class="form-group">
			<input type="submit" name="submit_form" value="Register" class="btn btn-primary">
			<input type="reset" value="Clear" class="btn btn-default">
			<a href="{{URL::action('SessionController@index')}}" class="btn btn-default" style="float:right;"><i class="fa fa-reply"></i> Back</a>
		</div>
		{{Form::token()}}
	</form>
</div>
@stop

@section('scripts')
	<script type="text/javascript">
		var cardnum = $("input[name='card_number']");

		cardnum.on("focusout", function(){
			$.ajax({
				url: "search_user/"+$(this).val(),
				dataType: 'json',
				type: 'get',
				success: function(user){
					if(user.success==1)
					{
						$("input[name='first_name']").val(user.first_name);
						$("input[name='last_name']").val(user.last_name);
						return true;
					}
					else
					{
						alert("The card number you entered is not valid or doesn't exists!");
						cardnum.focus();
						return false;
					}
				}
			});
		});
	</script>
@stop