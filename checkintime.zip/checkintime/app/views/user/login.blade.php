@extends('main')

@section('content')
		<div class="well col-md-5">
		<h1>Login</h1>
		{{ Form::open(['route' => 'session.start']) }}
			<div class="form-group">
				<input type="email" name="email" placeholder="Email" class='form-control' {{ Input::old('email') ? 'value="'.Input::old('email').'"' : ""   }} required>
			</div>
			<div class="form-group">
				<input type="password" name="password" placeholder="Password" class='form-control' required>
			</div>
			<div class="form-group">
				<button type="submit" name="login" class="btn btn-primary"><i class="fa fa-sign-in"></i> Login</button>
				<label for="rememberme">
					<input type="checkbox" id="rememberme" name="remember_me"> Remember me
				</label>
				<?php // <a href="{{URL::route('session.reset_pass_frm')}}" style="float:right">Forgot Password</a><br/>
				//<a href="#" style="float:right">Forgot Password</a><br/> ?>
				<a href="{{URL::route('session.register')}}" style="float:right">Register</a>
			</div>
		{{ Form::close() }}
		</div>
@stop